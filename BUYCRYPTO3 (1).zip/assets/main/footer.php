<footer>
					<div class="container">
						<div class="row">
							<div class="col-lg-4 I">
								<div>
									<div class="logos">
										<a class="navbar-brand gob"  target="_blank"><img src="images/Logotipo_Footer-DGT.svg" width="300" heigth="57" alt="Ministerio del interior - DGT"></a>
									</div>
									<h2>Sobre la DGT</h2>
									<div class="list list-group about">
										<p>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Sede Electrónica de la DGT</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Revista Tráfico y Seguridad Vial</a>
											<a  class="list-group-item list-group-item-action" target="_blank">Consejo Superior de Tráfico, Seguridad vial y Movilidad Sostenible</a>
											<a  class="list-group-item list-group-item-action" target="_blank">Facturación Electrónica y Perfil del Contratante</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Portal estadístico de la DGT</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Seguridad Vial 2030</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 C">
								<div>
									<h2>A un clic</h2>
									<div class="list list-group click">
										<p>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Ministerio del Interior</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Datos abiertos del Gobierno de España</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Punto de acceso a las Administraciones Públicas</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Cl@ve</a>
											<a  class="list-group-item list-group-item-action iconExternalLink" target="_blank">Portal de Transparencia de la AGE</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 D">
								<div>
									<style>
										.rrssFooter a
										{
										}

										.icon-twitter-foot
										{
											margin-top: 0;
										}
									</style>
									<h2>Contáctanos</h2>
									<ul class="list list-group contact">
										<li class="list-group-item">
											<span><a  class="list-group-item list-group-item-action">060</a></span>
											<span>Teléfono de atención al ciudadano</span>
										</li>
										<li class="list-group-item">
											<span><a  class="list-group-item list-group-item-action">011</a></span>
											<span>Teléfono de información de carreteras</span>
										</li>
										<li class="list-group-item">
											<span><a  class="list-group-item list-group-item-action">987 010 559</a></span>
											<span>Centro de tratamiento de denuncias automatizadas</span>
										</li>
										<li class="list-group-item li-rrssFooter">
											<span class="rrssFooter">
												<a class="icon-instagram-alt"  target="_blank"><span class="sr-only">Instagram</span></a>
												<a class="icon-twitter-foot"  target="_blank"><span class="sr-only">Twitter</span></a>
												<a class="icon-youtube"  target="_blank"><span class="sr-only">Youtube</span></a>
												<a class="icon-facebook-alt"  target="_blank"><span class="sr-only">Facebook</span></a>
											</span>
											<span>&nbsp;Redes Sociales</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="container-fluid d-flex justify-content-center mt-3">
						<div>
							<a  target="_blank">Aviso legal</a>
							<a  target="_blank">Política de privacidad</a>
							<a  target="_blank">Política de cookies</a>
							<a  target="_blank">Accesibilidad</a>
							<a >Mapa web</a>
						</div>
					</div>
				</footer>