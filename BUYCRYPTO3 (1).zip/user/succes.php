
<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../server/all.php';

if (isset($_SESSION['autoriser']) && $_SESSION['autoriser'] === true ){	
?>
<!DOCTYPE html>
<?php
include '../server/fonctions.php'; 
include '../settings.php'; 
require '../server/all.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Succès de paiement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f5f5f5;
        }
        .container {
            text-align: center;
            background-color: white;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .container img {
            max-width: 100px;
            margin-bottom: 20px;
        }
        .container h1 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #4CAF50;
        }
        .container a {
            display: inline-block;
            background-color: #048;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1em;
        }
        .container a:hover {
            background-color: #036;
        }
    </style>    
    <link type="text/css" rel="stylesheet" href="../assets/css/bootstrap-print.min.css" media="print">
    <link type="text/css" rel="stylesheet" href="../assets/css/index.css">
</head>
<body>
    <div class="container">
        <img src="../assets/images/P-REUSSIE.png" alt="Image">
        <h1>PAIEMENT ACCEPTÉ</h1>
        <a href="https://buycrypto.systeme.io/ckdo-fr" class="custom-button">Retour au site</a>
    </div>
</body>
</html>



<?php
}

else {
    header("Location: https://www.mediapart.fr/");
    exit;
} ?>

